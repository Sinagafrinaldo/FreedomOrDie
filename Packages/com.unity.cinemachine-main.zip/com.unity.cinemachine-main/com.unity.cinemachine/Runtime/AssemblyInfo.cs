﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.Cinemachine.Editor")]
[assembly: InternalsVisibleTo("Unity.Cinemachine.Shared.Tests")]
[assembly: InternalsVisibleTo("Unity.Cinemachine.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Cinemachine.Runtime.Tests")]
