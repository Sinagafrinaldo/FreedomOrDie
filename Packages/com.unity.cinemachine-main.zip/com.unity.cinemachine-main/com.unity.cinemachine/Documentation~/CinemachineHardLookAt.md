# Hard Look At

This CinemachineCamera __Rotation Control__ algorithm rotates the camera to keep the __Look At__ target in the center of the camera frame.

