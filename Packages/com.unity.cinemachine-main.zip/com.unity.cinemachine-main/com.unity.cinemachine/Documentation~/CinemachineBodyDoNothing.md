# None

This CinemachineCamera __Position Control__ setting does not procedurally modify the camera's position. Choose it for static shots or for animating the camera position directly with your custom scripts.

