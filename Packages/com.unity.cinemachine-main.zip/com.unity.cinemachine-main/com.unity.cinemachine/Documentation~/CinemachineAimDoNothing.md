# None

This CinemachineCamera __Rotation Control__ behavior does not procedurally aim the camera. Choose this for static shots or for animating the rotation directly with custom scripts.

